#!/usr/bin/env python
# coding: utf-8

# In[27]:


# coding: utf-8
#Extracting the users posting posts related to Sarcasm
# In[1]:


from bs4 import BeautifulSoup
import pandas as pd
from selenium import webdriver
import lxml
import csv


# In[2]:


driver_path = r"C:\Program Files\chromedriver.exe"
browser = webdriver.Chrome(driver_path)


# In[3]:


Asset = "https://twitter.com/SarcasticBro"
browser.get(Asset)



# In[28]:


a = browser.page_source
b = BeautifulSoup(a)
posted_by = []
# In[4]:
date = []
comments = []

for i in b.find_all("div", {"class" : "content"}):
	for j in i.find_all("div", {"class" : "stream-item-header"}):
		for k in j.find_all("a",{"class" : "account-group js-account-group js-action-profile js-user-profile-link js-nav"}):
			posted_by.append(k.text)
# In[5]:

for i in b.find_all("div", {"class" : "content"}):
	for j in i.find_all("div", {"class" : "stream-item-header"}):
		for k in j.find_all("small",{"class" : "time"}):
			date.append(k.text)

# In[6]:


for i in b.find_all("div", {"class" : "content"}):
	for j in i.find_all("div", {"class" : "js-tweet-text-container"}):
		for k in j.find_all("p"):
			comments.append(k.text)


# In[29]:


df = pd.DataFrame(posted_by, columns = ['Posted_by'])
df['Date'] = date
df['Comments'] = comments
df['Channel'] = "TWITTER/MICROBLOG"

# In[7]:
#Writing the results of the users with posts details into a csv file

df.to_excel(r"C:\Desktop\Emoji Analysis\Twitter_data.csv",index=False)

