#!/usr/bin/env python
# coding: utf-8

# In[11]:


# -*- coding: utf-8 -*-
import re
import csv
import os
from ExtraPreProc import remove_punctuations

os.chdir("C:\\Desktop\\Emoji Analysis\\Classification\\")

def main():
    pwd = os.getcwd();
    sarc_in = pwd + "\\data"
    sarc_out = pwd + "\\data_out"
    

    for f in os.listdir(sarc_in):
        inputDest = os.path.join(sarc_in,f)
        outputDest = os.path.join(sarc_out,f)
        inputFile = open(inputDest,"r",encoding="utf-8")
        outputFile = open(outputDest,"w", encoding = "utf-8")
        reader=csv.reader(inputFile)
        writer=csv.writer(outputFile)
        for row in reader:
            row[0]=preprocess(row[0])
            writer.writerow(row)
        inputFile.close()
        outputFile.close()

def preprocess(tweet):
    tweet = tweet.replace("#sarcasm","")                                                    #Removes the sarcasm hashtag
    tweet = tweet.replace("#sarcastic","")
    tweet = tweet.replace("#not","")
    tweet = re.sub(r"(?<=^|(?<=[^a-zA-Z0-9-_\.]))@([A-Za-z]+[A-Za-z0-9]+)", "", tweet)      #Removes mentions
    tweet = re.sub(r'(https?|ftp)://[^\s/$.?#].[^\s]*', '', tweet, flags=re.MULTILINE)      #Removes URL
    tweet = remove_punctuations(tweet)
    return tweet


if __name__=="__main__":
    main()

