#!/usr/bin/env python
# coding: utf-8

# In[1]:

import numpy as np
import csv
from sklearn import svm
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, BaggingClassifier, ExtraTreesClassifier, GradientBoostingClassifier
from sklearn.model_selection import KFold
from sklearn.preprocessing import OneHotEncoder
from sklearn import tree
import random
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import f1_score 

x = []
y = []

with open('C:/Desktop/Emoji Analysis/Classification/Data_Input/Input_Features.csv') as csvfile:
	reader = csv.reader(csvfile, delimiter = ' ')
	for row in reader:
		x.append(row[0: (len(row))])

for i in x:
	i[0] = i[0].split(',')
	y.append(i[0][-1])
	del i[0][-1]

X = []
for i in x:
	X.append(i[0])
Y = []
for i in y:
	Y.append(i)

    
print(len(Y))
print(type(X))
X = np.array(X)
Y = np.array(Y)
print(type(X))
for i in X:
	for j in i:
		j = float(j)

for i in Y:
	for j in i:
		j = float(j)
        

kfold = KFold(5, True, 1)
for train_index, test_index in kfold.split(X):
	#print(type(train_index))
	#print ("train:", train_index, "test:", test_index)
	x_train, x_test = X[train_index], X[test_index]
	y_train, y_test = Y[train_index], Y[test_index]

clf1 = svm.SVC(kernel = 'rbf')
clf1.fit(x_train, y_train)
predictions = clf1.predict(x_test)
predictions[0:30]
print("SVM RBF Kernel")
rbf_score=f1_score(y_test, predictions, average = 'macro')
print(rbf_score)


clftree = tree.DecisionTreeClassifier()
model2 = clftree.fit(x_train, y_train)
predictions = clftree.predict(x_test)
predictions[0:30]
print("Decision Tree Classifier")
dt_score=f1_score(y_test, predictions, average = 'macro')
print(dt_score)

clf4 = RandomForestClassifier()
clf4.fit(x_train, y_train)
predictions = clf4.predict(x_test)
predictions[0:30]
print("Random Forest classifier")
rf_score=f1_score(y_test,predictions, average = 'macro')
print(rf_score)

clf5 = AdaBoostClassifier()
clf5.fit(x_train, y_train)
predictions = clf5.predict(x_test)
predictions[0:30]
print("AdaBoost classifier")
ad_score = f1_score(y_test,predictions, average = 'macro')
print(ad_score)

clf6 = GradientBoostingClassifier()
clf6.fit(x_train, y_train)
predictions = clf6.predict(x_test)
predictions[0:30]
print("GradientBoosting Classifier")
gd_score = f1_score(y_test,predictions, average = 'macro')
print(gd_score)

clf7 = KNeighborsClassifier()
clf7.fit(x_train, y_train)
predictions = clf7.predict(x_test)
predictions[0:30]
print("KNN Classifier")
knn_score= f1_score(y_test,predictions, average = 'macro')
print(knn_score)


