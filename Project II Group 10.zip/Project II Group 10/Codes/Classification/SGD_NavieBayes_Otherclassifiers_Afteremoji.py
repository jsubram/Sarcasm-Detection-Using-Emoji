#!/usr/bin/env python
# coding: utf-8

# In[1]:
#SGDClassifier

import numpy as np
import csv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt
x = []
y = []

with open('Input_Features.csv') as csvfile:
	reader = csv.reader(csvfile, delimiter = ' ')
	for row in reader:
		x.append(row[0: (len(row))])

for i in x:
	i[0] = i[0].split(',')
	y.append(i[0][-1])
	del i[0][-1]

X = []
for i in x:
	X.append(i[0])
Y = []
for i in y:
	Y.append(i)

X = np.asarray(X)
Y = np.asarray(Y)

x = []
y = []


kfold = KFold(5, True, 1)
for train_index, test_index in kfold.split(X):
    print(type(train_index))
    print ("train:", train_index, "test:", test_index)
    x_train, x_test = X[train_index], X[test_index]
    y_train, y_test = Y[train_index], Y[test_index]

x_test = x_test.astype(float)
y_test = y_test.astype(float)
    

clf = SGDClassifier()
clf.fit(x_train, y_train)
predictions = clf.predict(x_test)
predictions[0:30]
predictions = predictions.astype(float)
print("SGDClassifier")
#print(clf.score(x_test, y_test))
from sklearn.metrics import f1_score 
print(f1_score(y_test, predictions, average = 'macro'))
print("\n")


# In[2]:
#Bayesian Classifier

import numpy as np
import csv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt
x = []
y = []

with open('Input_Features.csv') as csvfile:
	reader = csv.reader(csvfile, delimiter = ' ')
	for row in reader:
		x.append(row[0: (len(row))])

for i in x:
	i[0] = i[0].split(',')
	y.append(i[0][-1])
	del i[0][-1]

X = []
for i in x:
	X.append(i[0])
Y = []
for i in y:
	Y.append(i)


X = np.asarray(X)
Y = np.asarray(Y)

x = []
y = []

X = X.astype(int)
Y = Y.astype(int)


kfold = KFold(5, True, 1)
for train_index, test_index in kfold.split(X):
    print(type(train_index))
    print ("train:", train_index, "test:", test_index)
    x_train, x_test = X[train_index], X[test_index]
    y_train, y_test = Y[train_index], Y[test_index]

x_test = x_test.astype(float)
y_test = y_test.astype(float)

from sklearn.naive_bayes import GaussianNB
clfnb = GaussianNB()
clfnb.fit(x_train, y_train)
predictions = clf.predict(x_test)
predictions[0:30]
predictions = predictions.astype(float)
print("Bayesian Classifier")
#print(clf.score(x_test, y_test))
from sklearn.metrics import f1_score 
print(f1_score(y_test, predictions, average = 'macro'))
print("\n")


# In[3]:
#Extra Tree Classifier
from sklearn.ensemble import ExtraTreesClassifier

import numpy as np
import csv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt
x = []
y = []

with open('Input_Features.csv') as csvfile:
	reader = csv.reader(csvfile, delimiter = ' ')
	for row in reader:
		x.append(row[0: (len(row))])

for i in x:
	i[0] = i[0].split(',')
	y.append(i[0][-1])
	del i[0][-1]

X = []
for i in x:
	X.append(i[0])
Y = []
for i in y:
	Y.append(i)

#print(str(X[0]) + "\n")
#print(str(X[0])  + "     " + str(Y[4000]) + "\n")

X = np.asarray(X)
Y = np.asarray(Y)

x = []
y = []


kfold = KFold(5, True, 1)
for train_index, test_index in kfold.split(X):
    print(type(train_index))
    print ("train:", train_index, "test:", test_index)
    x_train, x_test = X[train_index], X[test_index]
    y_train, y_test = Y[train_index], Y[test_index]

x_test = x_test.astype(float)
y_test = y_test.astype(float)

clf = ExtraTreesClassifier()
clf.fit(x_train, y_train)
predictions = clf.predict(x_test)
predictions[0:30]
predictions = predictions.astype(float)
print("Extra Tree Classifier")
#print(clf.score(x_test, y_test))
from sklearn.metrics import f1_score 
print(f1_score(y_test, predictions, average = 'macro'))
print("\n")

