import pandas as pd
from collections import Counter
import re
import os
import numpy as np

replacement_patterns = [
(r'\xf0', ' \xf0'),
(r'\xe2', ' \xe2'),
(r'\xc2',r' \xc2')
]
class RegexpReplacer(object):
    def __init__(self, patterns=replacement_patterns):
        self.patterns = [(re.compile(regex), repl) for (regex, repl) in patterns]

    def replace(self, text):
        s = text
        for (pattern, repl) in self.patterns:
            s = re.sub(pattern, repl, s,re.I)
        return s

def Emoji_Position_Testing(Ans_Replaced):
    pos_index_new={}
    count_of_emojis={}
    list_temp=[]
    count_of_emojis_str=''
    for each,every in enumerate(re.split(r'\.|\s',Ans_Replaced)):
        list_temp.append((each,every))
    for pos, term in list_temp:
        if re.search('\xf0|\xe2|\xc2',term):
            list_global.append(term)
            pos_index_new.setdefault(term, []).append(pos)
    for index,value in pos_index_new.items():
        for index2,value2 in emoji_dictionary.items():
            if index==index2:
                count_of_emojis[value2]=len(value)
                count_of_emojis_str=str(count_of_emojis)
    return count_of_emojis_str
	
ip=pd.read_csv("C:\Desktop\Emoji Analysis\Emoji_Input.csv",index_col=False)
ip['Content'].dropna(axis=0,inplace=True)
ip.index=range(len(ip))
print ("File Row Count: ",len(ip))

ip_emoji=ip[ip['Content'].str.contains(r'\xf0|\xe2|\xc2',case=False)]
ip['Emoji_count']=''
ip = ip.astype('object')
emoji_dataset=pd.read_csv(r"C:\Desktop\Emoji Analysis\All_emoji_unicodes_updated.csv",index_col=False)
emoji_dictionary={}
emoji_dictionary=emoji_dataset.set_index('Emoji_hexcode_utf8')['Emoticon_Description'].to_dict()
list_global=[]

replacer = RegexpReplacer()
# initialized instance of the RegExpReplacer class

#Appending Emoji's in the main file
for each in ip_emoji.index:
    print (each)
    text=replacer.replace(ip.ix[each,'Content'])
    ip.ix[each,'Emoji_count']=Emoji_Position_Testing(text)

#ip.to_csv(r"..\Emoji_column_updated\Emoji_column_updated_PS2.csv",index=None)

#Finding out the top used Emoticons in the dataset
dict_overall_emoji_count=Counter(list_global)
dict_overall_emoji_count_readable={}
for key,value in dict_overall_emoji_count.items():
    for key2,value2 in emoji_dictionary.items():
        if key==key2:
            dict_overall_emoji_count_readable[value2]=value
op=pd.Series(dict_overall_emoji_count_readable)
op=pd.DataFrame({'Emojis':dict_overall_emoji_count_readable.keys(),'Count':dict_overall_emoji_count_readable.values()})
op.sort_values(['Count'],ascending=False,inplace=True)
op=op[['Emojis','Count']]
op.to_csv(r"C:\Desktop\Emoji Analysis\Emoji_Count data final.csv",index=None,header=True)

ip2=ip[ip['Emoji_count']!='']
print "Conversations with Emojis: ",len(ip2)
ip2.index=range(len(ip2))
ip2.to_csv(r"C:\Desktop\Emoji Analysis\Emoji_Count data final_convo.csv",index=None)
	