Codes:

Data Collection :
Data Collection-Twitter_SarcasticUS.py - Scraping the sarcastic comments in Twitter from Sarcastic page
Comments_fb.py - Extracting the comments for sarcastic pages in Facebook (sarcasmbro, sracasmLOL, etc)
Posts.py - Extracts the posts for sarcastic pages in Facebook (sarcasmbro, sracasmLOL, etc)

Feature Extraction: 
It has code for sentiment scoring - TextSentiment_Scoring_Code.py
and Emoji_Extrcation_Code.py for extracting emojis

Classification:
Contains the classification codes

Preprocessing :
Codes for preprocessing data

Data:
Conatins all the input and output data files.

Instructions to run the codes:

Step 1: Data is scarped from Twitter and Facebook using 
		Posts.py
		Comments_fb.py
		Data Collection-Twitter_SarcasticUS.py
		
Step 2: The output of scraped in stored in //Data//Data_Input//Datainput_preprosessing//Datainput_preprosessing.csv
		Preprocessing_data.py which uses ExtraPreProc.py
			
Step 3: The output of above steps are stored in //Data//Data_output
		TextSentiment_Scoring_Code.py
		Emoji_Extraction_Code.py
Step 4: The output of above steps are stored in //Data//Data_output and //Data//Emoji_output folderds respectively
		Classification_Algorithms_Beforeemoji.py
		Classification_Algorithms_Afteremoji.py
		SGD_NavieBayes_Otherclassifiers_Afteremoji.py
		SGD_NavieBayes_Otherclassifiers_Beforeemoji.py
		
These codes are run and input files to these codes are in //Data//Data_Input//Input_Features_Before.csv and //Data//Data_Input//Input_Features.csv respectively

      	